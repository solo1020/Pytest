# test sample

def func(x):
    # string = "good"
    # print(string[::])
    # print(string[::-1])
    return x + 1

def test_answer():
    assert func(3) == 5

